# Benchmark results

<!-- START table -->


<!-- END table -->

`*` indicates that the exact same versions of pyperformance was not used.
